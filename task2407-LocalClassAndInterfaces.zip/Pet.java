package com.codegym.task.task24.task2407;

public interface Pet {
    public CanSpeak toCanSpeak(int i);
}
