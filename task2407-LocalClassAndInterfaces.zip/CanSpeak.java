package com.codegym.task.task24.task2407;

public interface CanSpeak {
    String speak();
}
