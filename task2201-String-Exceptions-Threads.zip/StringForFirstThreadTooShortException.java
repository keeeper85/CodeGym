package com.codegym.task.task22.task2201;

public class StringForFirstThreadTooShortException extends RuntimeException {
}