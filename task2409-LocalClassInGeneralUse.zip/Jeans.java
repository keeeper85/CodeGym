package com.codegym.task.task24.task2409;

public interface Jeans extends Item{

    public int getLength();

    public int getSize();
}
