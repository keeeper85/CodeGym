package com.codegym.task.task24.task2409;

public interface Item {

    public int getId();

    public double getPrice();

    public String getTM();



}
