package com.codegym.task.task24.task2408;

public interface Pet {
    public CanSpeak toCanSpeak(int i);
}
