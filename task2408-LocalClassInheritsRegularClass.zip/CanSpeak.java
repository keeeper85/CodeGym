package com.codegym.task.task24.task2408;

public interface CanSpeak {
    String speak();
}
