package com.codegym.task.task24.task2410;

public interface Iterator {
    Iterator next();
}
