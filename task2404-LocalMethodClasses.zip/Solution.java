package com.codegym.task.task24.task2404;

import com.codegym.task.task24.task2404.HasHeight;
import com.codegym.task.task24.task2404.HasWidth;
import com.codegym.task.task24.task2404.Point;

/* 
Refactoring Rectangle
In the Rectangle class:
1. Change the getHeight and getWidth methods so that they return HasHeight and HasWidth objects, respectively.
2. To do this, inside the getHeight and getWidth methods, create local classes that implement the interfaces.
3. Rename getHeight to castToHasHeight, and getWidth to castToHasWidth (press Shift+F6 on the method name).
4. Remove the interface inheritance in the Rectangle class.

P.S. It is expected that after making the required changes, the commented code in the method will be uncommented and work correctly.


Requirements:
1. The Rectangle class must implement the castToHasHeight method.
2. The Rectangle class must implement the castToHasWidth method.
3. The castToHasHeight method must return a HasHeight object.
4. The castToHasWidth method must return a HasWidth object.
5. The object returned by the castToHasHeight method must calculate the height as the difference between the y coordinates.
6. The object returned by the castToHasWidth method must calculate the width as the difference between the x coordinates.
7. The Rectangle class should not implement the HasHeight interface.
8. The Rectangle class should not implement the HasWidth interface.
*/

public class Solution {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle(1, 2, 3, 4);
//        System.out.println(getHeight(rectangle));
//        System.out.println(getWidth(rectangle));
        /////////////////////expected//////////////////
        System.out.println(getHeight(rectangle.castToHasHeight()));
        System.out.println(getWidth(rectangle.castToHasWidth()));
    }

    public static double getHeight(HasHeight rectangle) {
        return rectangle.getHeight();
    }

    public static double getWidth(HasWidth rectangle) {
        return rectangle.getWidth();
    }


    public static class Rectangle{
        private Point point1;
        private Point point2;

        public Rectangle(double x1, double y1, double x2, double y2) {
            point1 = new Point(x1, y1);
            point2 = new Point(x2, y2);
        }

        public HasHeight castToHasHeight() {
            //return Math.abs(point1.getY() - point2.getY());

            return new HasHeight() {
                @Override
                public double getHeight() {
                    return Math.abs(point1.getY() - point2.getY());
                }
            };
        }

        public HasWidth castToHasWidth() {
            //return Math.abs(point1.getX() - point2.getX());


            return new HasWidth() {
                @Override
                public double getWidth() {
                    return Math.abs(point1.getX() - point2.getX());
                }
            };
        }
    }
}
