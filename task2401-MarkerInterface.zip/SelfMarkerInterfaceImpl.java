package com.codegym.task.task24.task2401;

public class SelfMarkerInterfaceImpl implements SelfMarkerInterface{

    public void method1(){}

    public void method2(){}
}
