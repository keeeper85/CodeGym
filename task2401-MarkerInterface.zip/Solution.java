package com.codegym.task.task24.task2401;

/* 
Creating your own marker interface

*/

public class Solution {
    public static void main(String[] args) throws UnsupportedMarkerInterfaceException {
        SelfMarkerInterfaceImpl obj = new SelfMarkerInterfaceImpl();
        Util.testClass(obj);
    }
}
