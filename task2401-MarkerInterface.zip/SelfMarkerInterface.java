package com.codegym.task.task24.task2401;

public interface SelfMarkerInterface {
}
