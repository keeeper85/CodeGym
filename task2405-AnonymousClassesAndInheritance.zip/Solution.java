package com.codegym.task.task24.task2405;

/* 
Black box
1. Repair the logic of the someAction method for the solutionAction field.
2. See the comment on the main method for example output.
3. Hint: if param > 0, then the someAction method of an anonymous class in the solutionAction field should call a method of the FirstClass subclass.
Otherwise, call a method of the SecondClass subclass.

Don't change the main method!


Requirements:
1. The screen output must match the task conditions.
2. The string constants declared in the SecondClass class should be used for the output.
3. The someAction method of the Action anonymous class created in the Solution class must call the someAction method of the parent class (super.someAction()).
4. A FirstClass object must be created in the someAction method of the Action anonymous class created in the Solution class.
5. A SecondClass object must be created in the someAction method of the Action anonymous class created in the Solution class.
*/

public class Solution implements Action {
    public static int actionObjectCount;

    private int param;

    private Action solutionAction = new Action() {
        //write your code here

        public void someAction() {
            //write your code here



            if (param > 0){

                while (param > 0){
                    System.out.println(param);
                    param--;
                }



                FirstClass firstClass = new FirstClass() {
                    @Override
                    public Action getDependentAction() {

                        super.someAction();

                        Action action = new Action() {
                            @Override
                            public void someAction() {


                            }
                        };



                        return action;
                    }
                };

                //firstClass.someAction();
                firstClass.getDependentAction();

            }

                SecondClass secondClass = new SecondClass();
                //secondClass.someAction();
                secondClass.sb.append(SecondClass.SPECIFIC_ACTION_FOR_ANONYMOUS_SECOND_CLASS_PARAM + param);
                System.out.println(secondClass.sb);
                //System.out.println(SecondClass.SPECIFIC_ACTION_FOR_ANONYMOUS_SECOND_CLASS_PARAM + param);

        }
    };


    public Solution(int param) {
        this.param = param;
    }

    @Override
    public void someAction() {
        solutionAction.someAction();
    }

    /**
     * 5
     * 4
     * 3
     * 2
     * 1
     * FirstClass class, someAction method
     * SecondClass class, someAction method
     * Specific action for anonymous SecondClass, param = 0
     * The number of created Action objects is 2
     * SecondClass class, someAction method
     * Specific action for anonymous SecondClass, param = -1
     * The number of created Action objects is 3
     */
    public static void main(String[] args) {



        Solution solution = new Solution(5);


        solution.someAction();
        System.out.println("The number of created Action objects is " + actionObjectCount);

        solution = new Solution(-1);
        solution.someAction();
        System.out.println("The number of created Action objects is " + actionObjectCount);
    }
}
