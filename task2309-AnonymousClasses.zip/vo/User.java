package com.codegym.task.task23.task2309.vo;

public class User extends NamedItem{


    public User(int id, String name, String description) {
        super.setId(id);
        super.setName(name);
        super.setDescription(description);
    }
}
