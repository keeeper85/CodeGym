package com.codegym.task.task23.task2309.vo;

public class Subject extends NamedItem{
}
