package com.codegym.task.task23.task2309.vo;

public class Server extends NamedItem{
}
